﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab02
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Course ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Student JOIN Course ON Student.Name = Course.Student_Name; ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Insert_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into Student values (@RegistrationNumber, @Name, @Department,@Session,@Address)", con);
            cmd.Parameters.AddWithValue("@RegistrationNumber", textBox1.Text);
            cmd.Parameters.AddWithValue("@Name", textBox2.Text);
            cmd.Parameters.AddWithValue("@Department", textBox3.Text);
            cmd.Parameters.AddWithValue("@Session", int.Parse(textBox4.Text));
            cmd.Parameters.AddWithValue("@Address", textBox5.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("INSERT INTO Course VALUES (@Course_ID, @Course_Name, @Student_Name, @Teacher_Name, @Semester)", con);
            cmd.Parameters.AddWithValue("@Course_ID", textBox6.Text);
            cmd.Parameters.AddWithValue("@Course_Name", textBox7.Text);
            cmd.Parameters.AddWithValue("@Student_Name", textBox8.Text);
            cmd.Parameters.AddWithValue("@Teacher_Name", textBox9.Text);
            cmd.Parameters.AddWithValue("@Semester", textBox10.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");

        }

        private void button9_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlTransaction transaction = null;

            try
            {
                con.Open();
                transaction = con.BeginTransaction();

                // Insert into Student table
                using (SqlCommand cmdStudent = new SqlCommand("INSERT INTO Student (RegistrationNumber, Name, Department, Session, Address) VALUES (@RegistrationNumber, @Name, @Department, @Session, @Address)", con, transaction))
                {
                    cmdStudent.Parameters.AddWithValue("@RegistrationNumber", textBox1.Text);
                    cmdStudent.Parameters.AddWithValue("@Name", textBox2.Text);
                    cmdStudent.Parameters.AddWithValue("@Department", textBox3.Text);
                    cmdStudent.Parameters.AddWithValue("@Session", int.Parse(textBox4.Text));
                    cmdStudent.Parameters.AddWithValue("@Address", textBox5.Text);
                    cmdStudent.ExecuteNonQuery();
                }

                // Insert into Course table
                using (SqlCommand cmdCourse = new SqlCommand("INSERT INTO Course (Course_ID, Course_Name, Student_Name, Teacher_Name, Semester) VALUES (@Course_ID, @Course_Name, @Student_Name, @Teacher_Name, @Semester)", con, transaction))
                {
                    cmdCourse.Parameters.AddWithValue("@Course_ID", textBox6.Text);
                    cmdCourse.Parameters.AddWithValue("@Course_Name", textBox7.Text);
                    cmdCourse.Parameters.AddWithValue("@Student_Name", textBox8.Text);
                    cmdCourse.Parameters.AddWithValue("@Teacher_Name", textBox9.Text);
                    cmdCourse.Parameters.AddWithValue("@Semester", textBox10.Text);
                    cmdCourse.ExecuteNonQuery();
                }

                transaction.Commit();
                MessageBox.Show("Successfully saved");
            }
            catch (Exception ex)
            {
                transaction?.Rollback();
                MessageBox.Show("Error saving data: " + ex.Message);
            }
            finally
            {
                transaction?.Dispose();
                con.Close();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("DELETE FROM Student WHERE RegistrationNumber = @RegistrationNumber", con);
                cmd.Parameters.AddWithValue("@RegistrationNumber", textBox1.Text);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Successfully deleted");
                }
                else
                {
                    MessageBox.Show("No matching record found for deletion.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting data: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("DELETE FROM Course WHERE Course_ID = @Course_ID", con);
                cmd.Parameters.AddWithValue("@Course_ID", textBox6.Text);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Successfully deleted");
                }
                else
                {
                    MessageBox.Show("No matching record found for deletion.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting data: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void Load_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("UPDATE Student SET Name = @Name, Department = @Department, Session = @Session, Address = @Address WHERE RegistrationNumber = @RegistrationNumber", con);
                cmd.Parameters.AddWithValue("@RegistrationNumber", textBox1.Text);
                cmd.Parameters.AddWithValue("@Name", textBox2.Text);
                cmd.Parameters.AddWithValue("@Department", textBox3.Text);
                cmd.Parameters.AddWithValue("@Session", int.Parse(textBox4.Text));
                cmd.Parameters.AddWithValue("@Address", textBox5.Text);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Successfully updated");
                }
                else
                {
                    MessageBox.Show("No matching record found for update.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating data: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("UPDATE Course SET Course_Name = @Course_Name, Student_Name = @Student_Name, Teacher_Name = @Teacher_Name, Semester = @Semester WHERE Course_ID = @Course_ID", con);
                cmd.Parameters.AddWithValue("@Course_ID", textBox6.Text);
                cmd.Parameters.AddWithValue("@Course_Name", textBox7.Text);
                cmd.Parameters.AddWithValue("@Student_Name", textBox8.Text);
                cmd.Parameters.AddWithValue("@Teacher_Name", textBox9.Text);
                cmd.Parameters.AddWithValue("@Semester", textBox10.Text);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Successfully updated");
                }
                else
                {
                    MessageBox.Show("No matching record found for update.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating data: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("SELECT * FROM Student WHERE RegistrationNumber = @RegistrationNumber", con);
                cmd.Parameters.AddWithValue("@RegistrationNumber", textBox1.Text);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dataGridView1.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("No matching record found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error searching data: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            try
            {
                con.Open();

                SqlCommand cmd = new SqlCommand("SELECT * FROM Course WHERE Course_ID = @Course_ID", con);
                cmd.Parameters.AddWithValue("@Course_ID", textBox6.Text);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dataGridView1.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("No matching record found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error searching data: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void Form2_Load_1(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlTransaction transaction = null;

            try
            {
                con.Open();
                transaction = con.BeginTransaction();

                using (SqlCommand cmdDeleteStudent = new SqlCommand("DELETE FROM Student WHERE RegistrationNumber = @RegistrationNumber", con, transaction))
                {
                    cmdDeleteStudent.Parameters.AddWithValue("@RegistrationNumber", textBox1.Text);
                    cmdDeleteStudent.ExecuteNonQuery();
                }

                using (SqlCommand cmdDeleteCourse = new SqlCommand("DELETE FROM Course WHERE Student_Name IN (SELECT Name FROM Student WHERE RegistrationNumber = @RegistrationNumber)", con, transaction))
                {
                    cmdDeleteCourse.Parameters.AddWithValue("@RegistrationNumber", textBox1.Text);
                    cmdDeleteCourse.ExecuteNonQuery();
                }

                transaction.Commit();
                MessageBox.Show("Successfully deleted");
            }
            catch (Exception ex)
            {
                transaction?.Rollback();
                MessageBox.Show("Error deleting data: " + ex.Message);
            }
            finally
            {
                transaction?.Dispose();
                con.Close();
            }

        }
    }
}
